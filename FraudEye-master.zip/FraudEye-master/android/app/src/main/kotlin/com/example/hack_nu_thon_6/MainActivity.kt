package com.example.hack_nu_thon_6

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
