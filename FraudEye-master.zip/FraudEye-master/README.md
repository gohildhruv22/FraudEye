## Important Urls:

#### `Website Url` : https://fraud-eye-6.web.app/ (Open in desktop)
#### `Normal Transaction API Code` : https://github.com/RamaniSaumya/FRAUDEYE
#### `Health Care API Code` : https://github.com/gohildhruv22/healthcare_api.git 


---

### FruadEye ScreenShots


![Screenshot 2025-03-31 130955](https://github.com/user-attachments/assets/35fdc566-a6b5-4059-972e-5816e570ea96)

![Screenshot 2025-03-31 131051](https://github.com/user-attachments/assets/ab4d81ee-8c3b-4c2b-aa37-a352e41dd35d)

![Screenshot 2025-03-31 131108](https://github.com/user-attachments/assets/69135eee-d244-4a02-8a70-5bddfd2c13b2)

![Screenshot 2025-03-31 131147](https://github.com/user-attachments/assets/04ef5005-235f-4356-871c-a85f717fae99)

![Screenshot 2025-03-31 131225](https://github.com/user-attachments/assets/c0377663-b903-4b02-aa66-c61bca622797)
